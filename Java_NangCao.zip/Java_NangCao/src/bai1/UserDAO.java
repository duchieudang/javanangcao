package bai1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
    public User selectByUsernameAndPassword(User t) {
        User ketQua = null;
        Connection con = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM accounts WHERE username=? AND password=?";  
            st = con.prepareStatement(sql);
            st.setString(1, t.getUsername());  
            st.setString(2, t.getPassword());  

            System.out.println(sql);
            rs = st.executeQuery();

            if (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                ketQua = new User(username, password);  
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        
            JDBCUtil.closeConnection(con);
            try {
                if (st != null) st.close();
                if (rs != null) rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return ketQua;
    }
    public static void main(String[] args) {
        // Create a UserDAO instance
        UserDAO userDAO = new UserDAO();

        // Create a User object with a sample username and password
        User user = new User("1", "1");

        // Call the selectByUsernameAndPassword method to check if the user exists
        User resultUser = userDAO.selectByUsernameAndPassword(user);

        // Check if a valid user was returned
        if (resultUser != null) {
            System.out.println("User found: " + resultUser.getUsername());
        } else {
            System.out.println("User not found or invalid credentials.");
        }
    }
}
