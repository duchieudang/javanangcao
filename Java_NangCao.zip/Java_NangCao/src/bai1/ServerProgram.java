package bai1;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ServerProgram {
    private static DefaultTableModel tableModel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Server Program");
        JTable table = new JTable();
        tableModel = new DefaultTableModel(new String[]{"PC Name", "IP", "Port", "Status", "Start Time", "End Time"}, 0);
        table.setModel(tableModel);
        frame.add(new JScrollPane(table));
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is running...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class ClientHandler extends Thread {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            String clientIP = socket.getInetAddress().getHostAddress();
            int clientPort = socket.getPort();
            String startTime = new Date().toString();
            updateTable("Client", clientIP, String.valueOf(clientPort), "Connected", startTime, "running");

            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            	  UserDAO userDAO=new UserDAO();
                  String username = in.readLine();
                  String password = in.readLine();
                  User user= new User(username, password);
                  User selectedUser = userDAO.selectByUsernameAndPassword(user);
               
                
          
                  if (selectedUser != null) {
                      out.println("true");
                  } else {
                      out.println("false");
                  }
                
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                updateTable("Client", clientIP, String.valueOf(clientPort), "Disconnected", startTime, new Date().toString());
            }
        }

        

        private void updateTable(String pcName, String ip, String port, String status, String startTime, String endTime) {
            SwingUtilities.invokeLater(() -> tableModel.addRow(new Object[]{pcName, ip, port, status, startTime, endTime}));
        }
    }
}
