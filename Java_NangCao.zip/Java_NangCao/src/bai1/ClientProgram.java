package bai1;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class ClientProgram {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Client Program");
        JPanel panel = new JPanel();
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(loginButton);
        frame.add(panel);

        frame.setSize(300, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            try (Socket socket = new Socket("localhost", 12345);
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                
                out.println(username);
                out.println(password);
                String response = in.readLine();
                if ("true".equals(response)) {
                    JOptionPane.showMessageDialog(frame, "Login thành công");
                } else {
                    JOptionPane.showMessageDialog(frame, "Login thất bại");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }
}
