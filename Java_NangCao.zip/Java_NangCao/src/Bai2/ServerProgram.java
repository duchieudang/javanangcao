package Bai2;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ServerProgram {
    private static DefaultTableModel tableModel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Server Program");
        JTable table = new JTable();
        tableModel = new DefaultTableModel(new String[]{"STT", "Họ Tên", "Mã Sinh Viên", "Ngày Sinh", "Giới Tính", "Ngoại Ngữ", "Điểm Trung Bình", "Thời Gian Cập Nhật"}, 0);
        table.setModel(tableModel);
        frame.add(new JScrollPane(table));
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is running...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                String action = in.readLine(); // Action: "add" or "update"
                String fullName = in.readLine();
                String studentId = in.readLine();
                String dateOfBirth = in.readLine();
                String gender = in.readLine();
                String foreignLanguage = in.readLine();
                String gpa = in.readLine();

                boolean success = false;
                if ("add".equals(action)) {
                    success = addRecordToDB(fullName, studentId, dateOfBirth, gender, foreignLanguage, gpa);
                } else if ("update".equals(action)) {
                    success = updateRecordInDB(studentId, fullName, dateOfBirth, gender, foreignLanguage, gpa);
                }

                out.println(success ? "true" : "false");
                if (success) {
                    updateTable();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private boolean addRecordToDB(String fullName, String studentId, String dateOfBirth, String gender, String foreignLanguage, String gpa) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "root", "password")) {
                String query = "INSERT INTO students (full_name, student_id, date_of_birth, gender, foreign_language, gpa) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, fullName);
                stmt.setString(2, studentId);
                stmt.setString(3, dateOfBirth);
                stmt.setString(4, gender);
                stmt.setString(5, foreignLanguage);
                stmt.setString(6, gpa);
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        private boolean updateRecordInDB(String studentId, String fullName, String dateOfBirth, String gender, String foreignLanguage, String gpa) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "root", "password")) {
                String query = "UPDATE students SET full_name = ?, date_of_birth = ?, gender = ?, foreign_language = ?, gpa = ? WHERE student_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, fullName);
                stmt.setString(2, dateOfBirth);
                stmt.setString(3, gender);
                stmt.setString(4, foreignLanguage);
                stmt.setString(5, gpa);
                stmt.setString(6, studentId);
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        private void updateTable() {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "root", "password")) {
                String query = "SELECT * FROM students";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                while (rs.next()) {
                    String fullName = rs.getString("full_name");
                    String studentId = rs.getString("student_id");
                    String dateOfBirth = rs.getString("date_of_birth");
                    String gender = rs.getString("gender");
                    String foreignLanguage = rs.getString("foreign_language");
                    String gpa = rs.getString("gpa");
                    String updatedTime = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy").format(new Date());

                    SwingUtilities.invokeLater(() -> tableModel.addRow(new Object[]{tableModel.getRowCount() + 1, fullName, studentId, dateOfBirth, gender, foreignLanguage, gpa, updatedTime}));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
