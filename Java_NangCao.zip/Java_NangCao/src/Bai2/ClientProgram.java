package Bai2;

import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class ClientProgram {
    private static JTextField fullNameField;
    private static JTextField studentIdField;
    private static JTextField dateOfBirthField;
    private static JTextField genderField;
    private static JTextField foreignLanguageField;
    private static JTextField gpaField;
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Client Program");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Margin between components

        fullNameField = new JTextField(20);
        studentIdField = new JTextField(10);
        dateOfBirthField = new JTextField(10);
        genderField = new JTextField(10);
        foreignLanguageField = new JTextField(10);
        gpaField = new JTextField(5);
        
        JButton connectButton = new JButton("Kết nối");
        JButton sendButton = new JButton("Gửi");
        JButton clearButton = new JButton("Thêm");
        JButton closeButton = new JButton("Đóng");

        // Customizing buttons
        connectButton.setBackground(new Color(64, 128, 255));
        sendButton.setBackground(new Color(0, 255, 0));
        clearButton.setBackground(new Color(255, 165, 0));
        closeButton.setBackground(new Color(255, 69, 0));

        // Set font for labels and buttons
        Font font = new Font("Arial", Font.PLAIN, 14);
        JLabel labelFullName = new JLabel("Họ Tên:");
        JLabel labelStudentId = new JLabel("Mã Sinh Viên:");
        JLabel labelDateOfBirth = new JLabel("Ngày Sinh:");
        JLabel labelGender = new JLabel("Giới Tính:");
        JLabel labelForeignLanguage = new JLabel("Ngoại Ngữ:");
        JLabel labelGpa = new JLabel("Điểm Trung Bình:");

        labelFullName.setFont(font);
        labelStudentId.setFont(font);
        labelDateOfBirth.setFont(font);
        labelGender.setFont(font);
        labelForeignLanguage.setFont(font);
        labelGpa.setFont(font);
        
        labelFullName.setPreferredSize(new Dimension(100, 30));
        labelStudentId.setPreferredSize(new Dimension(100, 30));
        labelDateOfBirth.setPreferredSize(new Dimension(100, 30));
        labelGender.setPreferredSize(new Dimension(100, 30));
        labelForeignLanguage.setPreferredSize(new Dimension(100, 30));
        labelGpa.setPreferredSize(new Dimension(100, 30));

        // Layout configuration
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(labelFullName, gbc);

        gbc.gridx = 1;
        panel.add(fullNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(labelStudentId, gbc);

        gbc.gridx = 1;
        panel.add(studentIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(labelDateOfBirth, gbc);

        gbc.gridx = 1;
        panel.add(dateOfBirthField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(labelGender, gbc);

        gbc.gridx = 1;
        panel.add(genderField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(labelForeignLanguage, gbc);

        gbc.gridx = 1;
        panel.add(foreignLanguageField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(labelGpa, gbc);

        gbc.gridx = 1;
        panel.add(gpaField, gbc);

        // Adding buttons
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(connectButton, gbc);

        gbc.gridx = 1;
        panel.add(sendButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(clearButton, gbc);

        gbc.gridx = 1;
        panel.add(closeButton, gbc);

        // Adding the panel to the frame
        frame.add(panel);
        frame.setVisible(true);

        // Button Action Listeners
        connectButton.addActionListener(e -> connectToServer());
        sendButton.addActionListener(e -> sendDataToServer());
        clearButton.addActionListener(e -> clearFields());
        closeButton.addActionListener(e -> System.exit(0));
    }

    private static void connectToServer() {
        try (Socket socket = new Socket("localhost", 12345)) {
            JOptionPane.showMessageDialog(null, "Kết nối thành công!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Kết nối thất bại!");
        }
    }

    private static void sendDataToServer() {
        try (Socket socket = new Socket("localhost", 12345);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("add");
            out.println(fullNameField.getText());
            out.println(studentIdField.getText());
            out.println(dateOfBirthField.getText());
            out.println(genderField.getText());
            out.println(foreignLanguageField.getText());
            out.println(gpaField.getText());

            String response = in.readLine();
            if ("true".equals(response)) {
                JOptionPane.showMessageDialog(null, "Thêm bản ghi thành công!");
            } else {
                JOptionPane.showMessageDialog(null, "Thêm bản ghi thất bại!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void clearFields() {
        fullNameField.setText("");
        studentIdField.setText("");
        dateOfBirthField.setText("");
        genderField.setText("");
        foreignLanguageField.setText("");
        gpaField.setText("");
    }
}
