package Bai2;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    // Use the getConnection method from JDBCUtil to get the database connection
    private Connection connection;

    public StudentDAO() {
        // Initialize the connection using JDBCUtil
        connection = JDBCUtil.getConnection();
    }

    // Method to retrieve all students
    public List<SinhVien> getAllSinhVien() {
        List<SinhVien> sinhVienList = new ArrayList<>();
        String query = "SELECT * FROM sinhvien";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                SinhVien sv = new SinhVien(
                        resultSet.getString("maSinhVien"),
                        resultSet.getString("hoVaTen"),
                        resultSet.getDate("ngaySinh"),
                        resultSet.getString("gioiTinh"),
                        resultSet.getString("ngoaiNgu"),
                        resultSet.getDouble("diemTB"),
                        resultSet.getTime("timeUpdate") // Assuming 'timeUpdate' is correct in DB
                );
                sinhVienList.add(sv);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Replace with a logger if needed
        }
        return sinhVienList;
    }

    // Method to add a new student
    public boolean addSinhVien(SinhVien sv) {
        String query = "INSERT INTO sinhvien (maSinhVien, hoVaTen, ngaySinh, gioiTinh, ngoaiNgu, diemTB) VALUES (?, ?, ?, ?, ?, ?)";
        boolean result = false;

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, sv.getMaSinhVien());
            preparedStatement.setString(2, sv.getHoVaTen());
            preparedStatement.setDate(3, new java.sql.Date(sv.getNgaySinh().getTime()));
            preparedStatement.setString(4, sv.getGioiTinh());
            preparedStatement.setString(5, sv.getNgoaiNgu());
            preparedStatement.setDouble(6, sv.getDiemTB());

            result = preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Replace with a logger if needed
        }
        return result;
    }
}
