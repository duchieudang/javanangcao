package controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Khoa;
import database.KhoaDAO;

@WebServlet("/khoa")
public class KhoaController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        KhoaDAO khoaDAO = new KhoaDAO();
        ArrayList<Khoa> listKhoa = khoaDAO.selectAll();
        request.setAttribute("listKhoa", listKhoa);

        // Kiểm tra nếu có yêu cầu hiển thị modal "Thêm khoa"
        String action = request.getParameter("action");
        if ("add".equals(action)) {
            request.setAttribute("showAddModal", true); // Truyền thông tin để mở modal
        }

        request.getRequestDispatcher("Khoa.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");
        KhoaDAO khoaDAO = new KhoaDAO();

        switch (action) {
            case "add":
                // Lấy dữ liệu từ form thêm khoa
                String maKhoa = request.getParameter("maKhoa");
                String tenKhoa = request.getParameter("tenKhoa");

                // Kiểm tra mã khoa trùng
                int dem = khoaDAO.sosanh(maKhoa);
        
                if (dem > 0) {
                	 request.setAttribute("status", "success4"); // Đánh dấu trạng thái là trùng mã khoa
                	    request.setAttribute("message", "Đã trùng mã khoa. Yêu cầu nhập lại!"); // Thông báo
                	    request.getRequestDispatcher("Khoa.jsp").forward(request, response); // Chuyển hướng đến Khoa.jsp
              

                } else {
                    // Tạo đối tượng khoa và thêm vào cơ sở dữ liệu
                    Khoa khoa = new Khoa(maKhoa, tenKhoa);
                    khoaDAO.insert(khoa);
                    response.sendRedirect("khoa?status=success"); // Chuyển hướng với thông báo thành công
                }
                return;

            case "delete":
                // Xóa khoa theo mã khoa
                String maKhoaToDelete = request.getParameter("maKhoa");
                Khoa khoaToDelete = new Khoa();
                khoaToDelete.setMaKhoa(maKhoaToDelete);
                khoaDAO.delete(khoaToDelete);
                response.sendRedirect("khoa?status=success2"); // Chuyển hướng với thông báo thành công
                return;

            case "update":
                // Cập nhật thông tin khoa
                String maKhoaToUpdate = request.getParameter("maKhoa");
                String newTenKhoa = request.getParameter("tenKhoa");
                Khoa khoaToUpdate = new Khoa(maKhoaToUpdate, newTenKhoa);
                khoaDAO.update(khoaToUpdate);
                response.sendRedirect("khoa?status=success3"); // Chuyển hướng với thông báo thành công
                return;

            default:
                response.sendRedirect("khoa?status=error&message=Invalid action"); // Xử lý nếu hành động không hợp lệ
                return;
        }
    }
}
