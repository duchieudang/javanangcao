package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.LopHoc;

public class LopHocDAO implements DAOInterface<LopHoc> {

    @Override
    public ArrayList<LopHoc> selectAll() {
        ArrayList<LopHoc> ketQua = new ArrayList<>();
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM lophoc";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maLopHoc = rs.getString("malophoc");
                String tenLopHoc = rs.getString("tenlophoc");
                String toaNha = rs.getString("toanha");
                String phong = rs.getString("phong");

                LopHoc lopHoc = new LopHoc(maLopHoc, tenLopHoc, toaNha, phong);
                ketQua.add(lopHoc);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public LopHoc selectById(LopHoc lopHoc) {
        LopHoc ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM lophoc WHERE malophoc=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, lopHoc.getMaLopHoc());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maLopHoc = rs.getString("malophoc");
                String tenLopHoc = rs.getString("tenlophoc");
                String toaNha = rs.getString("toanha");
                String phong = rs.getString("phong");

                ketQua = new LopHoc(maLopHoc, tenLopHoc, toaNha, phong);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insert(LopHoc lopHoc) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO lophoc (malophoc, tenlophoc, toanha, phong) VALUES (?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, lopHoc.getMaLopHoc());
            st.setString(2, lopHoc.getTenLopHoc());
            st.setString(3, lopHoc.getToaNha());
            st.setString(4, lopHoc.getPhong());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int update(LopHoc lopHoc) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "UPDATE lophoc SET tenlophoc=?, toanha=?, phong=? WHERE malophoc=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, lopHoc.getTenLopHoc());
            st.setString(2, lopHoc.getToaNha());
            st.setString(3, lopHoc.getPhong());
            st.setString(4, lopHoc.getMaLopHoc());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int delete(LopHoc lopHoc) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM lophoc WHERE malophoc=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, lopHoc.getMaLopHoc());
            ketQua = st.executeUpdate();
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int insertAll(ArrayList<LopHoc> arr) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "INSERT INTO lophoc (malophoc, tenlophoc, toanha, phong) VALUES (?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            for (LopHoc lopHoc : arr) {
                st.setString(1, lopHoc.getMaLopHoc());
                st.setString(2, lopHoc.getTenLopHoc());
                st.setString(3, lopHoc.getToaNha());
                st.setString(4, lopHoc.getPhong());
                ketQua += st.executeUpdate();
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
        
    }
    public LopHoc getLopHocByMaLopHoc(String maLopHoc) {
        LopHoc ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM lophoc WHERE malophoc=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maLopHoc);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String tenLopHoc = rs.getString("tenlophoc");
                String toaNha = rs.getString("toanha");
                String phong = rs.getString("phong");

                ketQua = new LopHoc(maLopHoc, tenLopHoc, toaNha, phong);
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public int deleteAll(ArrayList<LopHoc> arr) {
        int ketQua = 0;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "DELETE FROM lophoc WHERE malophoc=?";
            PreparedStatement st = con.prepareStatement(sql);
            for (LopHoc lopHoc : arr) {
                st.setString(1, lopHoc.getMaLopHoc());
                ketQua += st.executeUpdate();
            }
            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }
}
