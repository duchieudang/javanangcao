package model;

import java.util.Date;

public class SinhVien {
    private String maSinhVien;
    private String hoVaTen;
    private Date ngaySinh;
    private String gioiTinh;
    private String ngoaiNgu;
	public String getMaSinhVien() {
		return maSinhVien;
	}
	public void setMaSinhVien(String maSinhVien) {
		this.maSinhVien = maSinhVien;
	}
	public String getHoVaTen() {
		return hoVaTen;
	}
	public void setHoVaTen(String hoVaTen) {
		this.hoVaTen = hoVaTen;
	}
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public String getNgoaiNgu() {
		return ngoaiNgu;
	}
	public void setNgoaiNgu(String ngoaiNgu) {
		this.ngoaiNgu = ngoaiNgu;
	}
	public SinhVien(String maSinhVien, String hoVaTen, Date ngaySinh, String gioiTinh, String ngoaiNgu) {
		super();
		this.maSinhVien = maSinhVien;
		this.hoVaTen = hoVaTen;
		this.ngaySinh = ngaySinh;
		this.gioiTinh = gioiTinh;
		this.ngoaiNgu = ngoaiNgu;
	}
	public SinhVien() {
		super();
	}

    
}
