package controller;

import dao.SinhVienDAO;
import model.SinhVien;
import view.SinhVienView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class QuanLySinhVienController {
    private SinhVienView view;
    private SinhVienDAO dao;

    public QuanLySinhVienController(SinhVienView view, SinhVienDAO dao) {
        this.view = view;
        this.dao = dao;

        // Load data on start
        loadTableData();

        // Add listeners
        view.getLoadButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadTableData();
            }
        });

        view.getExitButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    // Load data into table
    private void loadTableData() {
        List<SinhVien> sinhVienList = dao.getAllSinhVien();
        view.getTableModel().setRowCount(0); 
        for (SinhVien sv : sinhVienList) {
            view.getTableModel().addRow(new Object[]{
                sv.getMaSinhVien(),
                sv.getHoVaTen(),
                sv.getNgaySinh(),
                sv.getGioiTinh(),
                sv.getNgoaiNgu()
            });
        }
    }
}
