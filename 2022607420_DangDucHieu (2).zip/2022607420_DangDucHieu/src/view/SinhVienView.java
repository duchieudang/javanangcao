
package view;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import dao.SinhVienDAO;
import model.SinhVien;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SinhVienView extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField nameField, idField;
    private JFormattedTextField birthDateField;
    private JRadioButton maleRadio, femaleRadio;
    private JCheckBox englishCheckBox, frenchCheckBox, russianCheckBox;
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton addButton, loadButton, exitButton;

    public SinhVienView() {
    	   SinhVienDAO sinhVienDAO=new SinhVienDAO();
        setTitle("QUAN LY SINH VIEN");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500);
        JPanel contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Input Panel
        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(new TitledBorder("Nhap"));
        inputPanel.setBounds(10, 10, 350, 200);
        contentPane.add(inputPanel);
        inputPanel.setLayout(null);

        JLabel nameLabel = new JLabel("Ho va ten:");
        nameLabel.setBounds(10, 20, 80, 20);
        inputPanel.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(100, 20, 220, 20);
        inputPanel.add(nameField);

        JLabel idLabel = new JLabel("Ma sinh vien:");
        idLabel.setBounds(10, 50, 80, 20);
        inputPanel.add(idLabel);

        idField = new JTextField();
        idField.setBounds(100, 50, 220, 20);
        inputPanel.add(idField);

        JLabel birthDateLabel = new JLabel("Ngay sinh:");
        birthDateLabel.setBounds(10, 80, 80, 20);
        inputPanel.add(birthDateLabel);

        birthDateField = new JFormattedTextField(new SimpleDateFormat("dd/MM/yyyy"));
        birthDateField.setBounds(100, 80, 220, 20);
        inputPanel.add(birthDateField);

        // Gender Label
        JLabel genderLabel = new JLabel("Gioi tinh:");
        genderLabel.setBounds(10, 110, 80, 20);
        inputPanel.add(genderLabel);

        // Gender Radio Buttons
        maleRadio = new JRadioButton("Nam");
        femaleRadio = new JRadioButton("Nu");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        maleRadio.setBounds(100, 110, 60, 20);
        femaleRadio.setBounds(170, 110, 60, 20);
        inputPanel.add(maleRadio);
        inputPanel.add(femaleRadio);

        // Foreign language
        JLabel langLabel = new JLabel("Ngoai ngu:");
        langLabel.setBounds(10, 140, 80, 20);
        inputPanel.add(langLabel);

        englishCheckBox = new JCheckBox("Anh");
        frenchCheckBox = new JCheckBox("Phap");
        russianCheckBox = new JCheckBox("Nga");
        englishCheckBox.setBounds(100, 140, 60, 20);
        frenchCheckBox.setBounds(170, 140, 60, 20);
        russianCheckBox.setBounds(240, 140, 60, 20);
        inputPanel.add(englishCheckBox);
        inputPanel.add(frenchCheckBox);
        inputPanel.add(russianCheckBox);

        // Table
        tableModel = new DefaultTableModel(new String[]{"Ma SV", "Ho ten", "Ngay sinh", "Gioi tinh", "Ngoai ngu"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(370, 10, 400, 200);
        contentPane.add(scrollPane);

        // Buttons
        addButton = new JButton("Them");
        addButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        	}
        });
        addButton.setBounds(10, 220, 100, 30);
        contentPane.add(addButton);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Lấy thông tin từ các trường nhập liệu
                String name = nameField.getText();
                String id = idField.getText();
                String birthDateString = birthDateField.getText(); // Sử dụng birthDateString để lưu chuỗi ngày sinh
                String gender = maleRadio.isSelected() ? "Nam" : "Nữ";  // Kiểm tra giới tính
                
                // Kiểm tra các checkbox ngôn ngữ
                StringBuilder languages = new StringBuilder();
                if (englishCheckBox.isSelected()) {
                    languages.append("Anh ");
                }
                if (frenchCheckBox.isSelected()) {
                    languages.append("Pháp ");
                }
                if (russianCheckBox.isSelected()) {
                    languages.append("Nga ");
                }
                
                // Chuyển đổi chuỗi ngày tháng thành đối tượng Date
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                java.util.Date birthDate = null;
                try {
                    birthDate = dateFormat.parse(birthDateString);
                } catch (ParseException ex) {
                    JOptionPane.showMessageDialog(null, "Ngày sinh không hợp lệ. Vui lòng nhập đúng định dạng dd/MM/yyyy.");
                    ex.printStackTrace(); // Optional: You can remove this in production code
                    return; // Stop further processing if the date is invalid
                }

                // Tạo đối tượng SinhVien
                SinhVien sv = new SinhVien(id, name, birthDate, gender, languages.toString());
             
                if(sinhVienDAO.addSinhVien(sv)) 
                	   JOptionPane.showMessageDialog(null, "Sinh viên đã được thêm thành công.");
                // Thêm dòng mới vào bảng
                Object[] newRow = {id, name, birthDate, gender, languages.toString()};
                tableModel.addRow(newRow);

                // Làm sạch các trường nhập liệu sau khi thêm
                nameField.setText("");
                idField.setText("");
                birthDateField.setText("");
                maleRadio.setSelected(false);
                femaleRadio.setSelected(false);
                englishCheckBox.setSelected(false);
                frenchCheckBox.setSelected(false);
                russianCheckBox.setSelected(false);
            }
        });

        loadButton = new JButton("Tai lai");
        loadButton.setBounds(120, 220, 100, 30);
        contentPane.add(loadButton);

        exitButton = new JButton("Thoat");
        exitButton.setBounds(230, 220, 100, 30);
        contentPane.add(exitButton);
    }

    // Getters for components (to be accessed by controller)
   

    

   
    public DefaultTableModel getTableModel() {
        return tableModel;
    }

  

    public JButton getLoadButton() {
        return loadButton;
    }

    public JButton getExitButton() {
        return exitButton;
    }

    // Method to refresh table data from controller
    public void refreshTableData(Object[][] data) {
        tableModel.setRowCount(0);  // Clear existing data
        for (Object[] row : data) {
            tableModel.addRow(row);  // Add new data to table
        }
    }
}

