package main;

import controller.QuanLySinhVienController;
import dao.SinhVienDAO;
import view.SinhVienView;

public class Main {
    public static void main(String[] args) {
        SinhVienView view = new SinhVienView();
        SinhVienDAO dao = new SinhVienDAO();
        new QuanLySinhVienController(view, dao);

        view.setVisible(true);
    }
}
